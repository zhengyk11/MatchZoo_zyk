python -u main.py --device 0 --phase train --model_file ../config/MP/MP_0.config > ../logs/MP/MP_0.log
